# SDST-GraphNet

SDST-GraphNet（Static–Dynamic Spatio-Temporal Graph Network，静动态时空图网络）
是一个道路节点级、直接多步交通速度预测模型。它将动态交通时序经过
STGCN 编码，将道路环境静态特征经过 MLP 编码，再通过 1×1 卷积进行中间融合。

## Architecture

```text
dynamic [B,12,N,6] ── STGCN block 1 ── Hd [B,8,N,64] ─┐
                                                       ├─ concat ─ 1x1 Conv(128→64)
static [N,14] ── MLP(14→64→64) ── Hs ── broadcast ────┘
    ── STGCN block 2 ── temporal readout ── MLP ── [B,9,N,1]
```

Dynamic feature order: speed, speed mask, flow, flow mask, time sin, time cos.
Static feature order is stored in the checkpoint and includes two road attributes,
six POI variables, and six street-view variables.

## Privacy boundary

This repository contains no trajectories, speed/flow observations, POI/SVI values,
road geometry, node IDs, adjacency matrices, real dates, dataset paths, split files,
or normalization statistics. Those files are gitignored. The released checkpoint
also excludes graph-support buffers and training statistics.

## Install

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -e .
```

## Private array contract

The data owner supplies locally:

- `dynamic.npy`: normalized float32 `[T,N,6]`;
- `static.npy`: normalized float32 `[N,14]`;
- `target.npy`: normalized speed `[T,N,1]`;
- `target_mask.npy`: observed-label mask `[T,N,1]`;
- `adjacency.npz`: scipy sparse road graph, using exactly the checkpoint node order;
- private normalization JSON with `target_mean` and `target_std`.

Continuous variables must be standardized using **training data only**. Mask fields
remain 0/1. Never fit a scaler using validation/test periods.

## Leakage-safe split

Use chronological boundaries; every history and target window remains wholly inside
one split. For example:

```powershell
python make_splits.py --length 8928 --train-end 6000 --val-end 7400 --output private/splits.npz
```

The numeric boundaries above are illustrative, not project dates.

## Train

Copy `configs/example.json`, point it at private local files, then run:

```powershell
python train.py --config private/train_config.json
```

Training uses masked MSE, RMSProp, a StepLR schedule, validation MAE checkpointing,
and optional early stopping. Metrics are computed only where `target_mask=1`.

## Offline inference

Prepare one or more normalized histories as `[B,12,N,6]`:

```powershell
python infer.py --history private/history.npy --static private/static.npy `
  --adjacency private/adjacency.npz --normalization private/normalization.json `
  --output outputs/prediction.npy
```

## Static-feature Integrated Gradients

Single node, 5-minute horizon (node index is private node ordering, not a public ID):

```powershell
python explain_ig.py --history private/history.npy --static private/static.npy `
  --adjacency private/adjacency.npz --node-index 123 --horizon 1 `
  --output outputs/node_123_h5.csv
```

Network-wide mean explanation: omit `--node-index`. The zero baseline represents
the training mean because static inputs are standardized. Signed attribution is
reported for a node; global ranking averages absolute attribution across nodes.

## Verify

```powershell
pip install pytest
pytest -q
```

No license is asserted automatically. Add the license appropriate to your project
before publishing the repository.

