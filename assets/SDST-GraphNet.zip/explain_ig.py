from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from sdst_graphnet.graph import load_supports
from sdst_graphnet.model import SDSTGraphNet


def main() -> None:
    parser = argparse.ArgumentParser(description="Integrated Gradients for static SDST-GraphNet inputs.")
    parser.add_argument("--weights", default="weights/sdst_graphnet_pretrained.pt")
    parser.add_argument("--history", required=True, help="Normalized NPY [B,12,N,6].")
    parser.add_argument("--static", required=True, help="Normalized NPY [N,14].")
    parser.add_argument("--adjacency", required=True)
    parser.add_argument("--node-index", type=int, help="Omit for network-wide mean explanation.")
    parser.add_argument("--horizon", type=int, default=1, choices=range(1, 10))
    parser.add_argument("--steps", type=int, default=32)
    parser.add_argument("--output", default="outputs/ig_static.csv")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    device = torch.device(args.device)
    checkpoint = torch.load(args.weights, map_location=device, weights_only=False)
    arch = checkpoint["architecture"]
    dynamic = torch.from_numpy(np.load(args.history).astype(np.float32)).to(device)
    actual = torch.from_numpy(np.load(args.static).astype(np.float32)).to(device)
    supports = load_supports(args.adjacency, arch["chebyshev_order"], device)
    model = SDSTGraphNet(supports, actual.shape[0], arch["history"], arch["horizon"],
                         arch["dynamic_channels"], actual.shape[1], arch["hidden_channels"],
                         tuple(tuple(x) for x in arch["blocks"]), arch["dropout"]).to(device)
    model.load_state_dict(checkpoint["state_dict"]); model.eval()
    baseline = torch.zeros_like(actual)
    gradient_sum = torch.zeros_like(actual)
    for alpha in torch.linspace(0.0, 1.0, args.steps, device=device):
        interpolated = (baseline + alpha * (actual - baseline)).detach().requires_grad_(True)
        prediction = model(dynamic, interpolated)[:, args.horizon - 1, :, 0]
        objective = prediction[:, args.node_index].mean() if args.node_index is not None else prediction.mean()
        gradient_sum += torch.autograd.grad(objective, interpolated)[0].detach()
    attribution = ((actual - baseline) * gradient_sum / args.steps).detach().cpu().numpy()
    if args.node_index is not None:
        values = attribution[args.node_index]
    else:
        values = np.mean(np.abs(attribution), axis=0)
    names = checkpoint["static_feature_names"]
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["feature", "attribution", "absolute_attribution"])
        writer.writeheader()
        for name, value in sorted(zip(names, values), key=lambda item: abs(item[1]), reverse=True):
            writer.writerow({"feature": name, "attribution": float(value), "absolute_attribution": float(abs(value))})
    print(json.dumps({"scope": "node" if args.node_index is not None else "global",
                      "node_index": args.node_index, "horizon_minutes": args.horizon * 5,
                      "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()

