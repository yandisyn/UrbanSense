"""Convert a private training checkpoint into a topology/scaler-free public checkpoint."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch


FEATURES_DYNAMIC = ["speed", "speed_mask", "flow", "flow_mask", "time_sin", "time_cos"]
FEATURES_STATIC = [
    "length_m", "road_class", "poi_diversity_normalized_shannon", "poi_density_per_km2",
    "residential_poi_density_per_km2", "commercial_poi_density_per_km2",
    "public_service_poi_density_per_km2", "industrial_related_poi_density_per_km2",
    "road_ratio", "sidewalk_ratio", "building_ratio", "vegetation_ratio", "sky_ratio",
    "traffic_sign_ratio",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="weights/sdst_graphnet_pretrained.pt")
    args = parser.parse_args()
    source = torch.load(args.input, map_location="cpu", weights_only=False)
    state = source.get("model_state", source.get("state_dict"))
    clean = {key: value for key, value in state.items() if ".support_" not in key}
    package = {
        "format_version": 1,
        "model_name": "SDSTGraphNet",
        "architecture": {"history": int(source["n_his"]), "horizon": int(source["n_pred"]),
                         "dynamic_channels": len(FEATURES_DYNAMIC), "static_channels": len(FEATURES_STATIC),
                         "hidden_channels": int(source["hidden_channels"]),
                         "blocks": [list(item) for item in source["blocks"]],
                         "dropout": float(source["dropout"]), "chebyshev_order": 3},
        "n_nodes": int(source["n_nodes"]),
        "dynamic_feature_names": FEATURES_DYNAMIC,
        "static_feature_names": FEATURES_STATIC,
        "state_dict": clean,
        "privacy": "No observations, identifiers, topology, geometry, split dates, paths, or normalization statistics.",
    }
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(package, output)
    print(f"Saved {output} ({output.stat().st_size / 1024**2:.2f} MiB)")


if __name__ == "__main__":
    main()

