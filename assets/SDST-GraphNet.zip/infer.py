from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from sdst_graphnet.graph import load_supports
from sdst_graphnet.model import SDSTGraphNet


def main() -> None:
    parser = argparse.ArgumentParser(description="Offline SDST-GraphNet inference.")
    parser.add_argument("--weights", default="weights/sdst_graphnet_pretrained.pt")
    parser.add_argument("--history", required=True, help="NPY [B,12,N,6], already normalized.")
    parser.add_argument("--static", required=True, help="NPY [N,14], already normalized.")
    parser.add_argument("--adjacency", required=True, help="Private scipy sparse adjacency NPZ.")
    parser.add_argument("--normalization", help="Private JSON containing target_mean and target_std.")
    parser.add_argument("--output", default="outputs/prediction.npy")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    device = torch.device(args.device)
    checkpoint = torch.load(args.weights, map_location=device, weights_only=False)
    arch = checkpoint["architecture"]
    dynamic = torch.from_numpy(np.load(args.history).astype(np.float32)).to(device)
    static = torch.from_numpy(np.load(args.static).astype(np.float32)).to(device)
    supports = load_supports(args.adjacency, arch["chebyshev_order"], device)
    model = SDSTGraphNet(supports, n_nodes=static.shape[0], n_his=arch["history"], n_pred=arch["horizon"],
                         dynamic_channels=arch["dynamic_channels"], static_channels=static.shape[1],
                         hidden_channels=arch["hidden_channels"], blocks=tuple(tuple(x) for x in arch["blocks"]),
                         dropout=arch["dropout"]).to(device)
    model.load_state_dict(checkpoint["state_dict"], strict=True); model.eval()
    with torch.no_grad():
        prediction = model(dynamic, static).cpu().numpy()
    if args.normalization:
        scaling = json.loads(Path(args.normalization).read_text(encoding="utf-8"))
        prediction = prediction * float(scaling["target_std"]) + float(scaling["target_mean"])
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    np.save(output, prediction)
    print(f"Saved {prediction.shape} to {output}")


if __name__ == "__main__":
    main()

