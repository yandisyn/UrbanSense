from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from sdst_graphnet.data import valid_starts


def main() -> None:
    parser = argparse.ArgumentParser(description="Create leakage-safe chronological window indices.")
    parser.add_argument("--length", type=int, required=True, help="Number of time steps.")
    parser.add_argument("--train-end", type=int, required=True, help="Exclusive training boundary index.")
    parser.add_argument("--val-end", type=int, required=True, help="Exclusive validation boundary index.")
    parser.add_argument("--history", type=int, default=12)
    parser.add_argument("--horizon", type=int, default=9)
    parser.add_argument("--output", default="private/splits.npz")
    args = parser.parse_args()
    if not 0 < args.train_end < args.val_end < args.length + 1:
        raise ValueError("Require 0 < train_end < val_end <= length.")
    arrays = {
        "train": valid_starts(args.length, args.history, args.horizon, 0, args.train_end),
        "val": valid_starts(args.length, args.history, args.horizon, args.train_end, args.val_end),
        "test": valid_starts(args.length, args.history, args.horizon, args.val_end, args.length),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, **arrays)
    print(json.dumps({key: int(len(value)) for key, value in arrays.items()}, indent=2))


if __name__ == "__main__":
    main()

