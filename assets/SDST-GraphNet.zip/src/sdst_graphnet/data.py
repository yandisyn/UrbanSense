from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset


class WindowDataset(Dataset):
    """Memory-mapped arrays; windows are explicitly supplied to prevent leakage."""

    def __init__(self, dynamic_path: str, target_path: str, mask_path: str,
                 starts: np.ndarray, history: int = 12, horizon: int = 9) -> None:
        self.dynamic = np.load(dynamic_path, mmap_mode="r")
        self.target = np.load(target_path, mmap_mode="r")
        self.mask = np.load(mask_path, mmap_mode="r")
        self.starts = np.asarray(starts, dtype=np.int64)
        self.history, self.horizon = history, horizon

    def __len__(self) -> int:
        return len(self.starts)

    def __getitem__(self, index: int):
        start = int(self.starts[index])
        split = start + self.history
        end = split + self.horizon
        x = np.asarray(self.dynamic[start:split], dtype=np.float32).copy()
        y = np.asarray(self.target[split:end], dtype=np.float32).copy()
        m = np.asarray(self.mask[split:end], dtype=np.float32).copy()
        return torch.from_numpy(x), torch.from_numpy(y), torch.from_numpy(m)


def valid_starts(length: int, history: int, horizon: int, begin: int, end: int) -> np.ndarray:
    """Return starts whose full input and target remain inside [begin, end)."""
    first, last = begin, end - history - horizon
    return np.arange(first, last + 1, dtype=np.int64) if last >= first else np.empty(0, dtype=np.int64)

