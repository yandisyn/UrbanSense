from __future__ import annotations

import numpy as np
import torch
from scipy import sparse
from scipy.sparse.csgraph import laplacian
from scipy.sparse.linalg import eigsh


def chebyshev_supports(adjacency: sparse.spmatrix, order: int = 3) -> list[sparse.csr_matrix]:
    adjacency = adjacency.astype(np.float32).tocsr()
    lap = laplacian(adjacency, normed=True).astype(np.float32).tocsr()
    largest = 1.0 if adjacency.shape[0] == 1 else float(eigsh(lap, k=1, which="LM", return_eigenvectors=False)[0])
    if not np.isfinite(largest) or largest <= 0:
        largest = 2.0
    identity = sparse.identity(adjacency.shape[0], dtype=np.float32, format="csr")
    scaled = (2.0 / largest * lap - identity).tocsr()
    result = [identity]
    if order > 1:
        result.append(scaled)
    for _ in range(2, order):
        result.append((2.0 * scaled @ result[-1] - result[-2]).tocsr())
    return result


def to_torch_sparse(matrix: sparse.spmatrix, device=None) -> torch.Tensor:
    matrix = matrix.tocoo()
    indices = torch.tensor(np.vstack((matrix.row, matrix.col)), dtype=torch.long)
    values = torch.tensor(matrix.data, dtype=torch.float32)
    return torch.sparse_coo_tensor(indices, values, matrix.shape, device=device).coalesce()


def load_supports(path: str, order: int = 3, device=None) -> list[torch.Tensor]:
    adjacency = sparse.load_npz(path)
    return [to_torch_sparse(item, device) for item in chebyshev_supports(adjacency, order)]

