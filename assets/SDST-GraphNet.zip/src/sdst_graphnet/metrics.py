from __future__ import annotations

import torch


def masked_mse(prediction: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return ((prediction - target).square() * mask).sum() / mask.sum().clamp_min(1.0)


def masked_metrics(prediction: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> dict[str, float]:
    error = prediction - target
    count = mask.sum().clamp_min(1.0)
    mae = (error.abs() * mask).sum() / count
    mse = (error.square() * mask).sum() / count
    wmape = (error.abs() * mask).sum() / (target.abs() * mask).sum().clamp_min(1e-8)
    return {"mae": mae.item(), "mse": mse.item(), "rmse": mse.sqrt().item(), "wmape": wmape.item()}

