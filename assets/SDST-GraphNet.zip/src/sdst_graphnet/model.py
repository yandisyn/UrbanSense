"""SDST-GraphNet architecture. No project data or graph is embedded here."""

from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import nn
from torch.nn import functional as F


def _xavier(module: nn.Module) -> None:
    for child in module.modules():
        if isinstance(child, (nn.Conv2d, nn.Linear)):
            nn.init.xavier_uniform_(child.weight)
            if child.bias is not None:
                nn.init.zeros_(child.bias)


class NodeLayerNorm(nn.Module):
    def __init__(self, n_nodes: int, channels: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.gamma = nn.Parameter(torch.ones(1, 1, n_nodes, channels))
        self.beta = nn.Parameter(torch.zeros(1, 1, n_nodes, channels))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mean = x.mean(dim=(2, 3), keepdim=True)
        variance = (x - mean).square().mean(dim=(2, 3), keepdim=True)
        return (x - mean) * torch.rsqrt(variance + self.eps) * self.gamma + self.beta


class TemporalConv(nn.Module):
    def __init__(self, kt: int, c_in: int, c_out: int, activation: str) -> None:
        super().__init__()
        self.kt, self.c_in, self.c_out, self.activation = kt, c_in, c_out, activation
        self.conv = nn.Conv2d(c_in, 2 * c_out if activation == "GLU" else c_out, (kt, 1))
        self.residual_projection = nn.Linear(c_in, c_out, bias=False) if c_in > c_out else None
        _xavier(self)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.residual_projection is not None:
            residual = self.residual_projection(x)
        elif self.c_in < self.c_out:
            residual = F.pad(x, (0, self.c_out - self.c_in))
        else:
            residual = x
        residual = residual[:, self.kt - 1 :]
        convolved = self.conv(x.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        if self.activation == "GLU":
            linear, gate = torch.chunk(convolved, 2, dim=-1)
            return (linear + residual) * torch.sigmoid(gate)
        return torch.relu(convolved + residual)


class ChebyshevGraphConv(nn.Module):
    def __init__(self, supports: Sequence[torch.Tensor], c_in: int, c_out: int) -> None:
        super().__init__()
        self.support_names: list[str] = []
        for index, support in enumerate(supports):
            name = f"support_{index}"
            # Graph topology is deployment data, not part of the public checkpoint.
            self.register_buffer(name, support.coalesce(), persistent=False)
            self.support_names.append(name)
        self.linear = nn.Linear(len(supports) * c_in, c_out)
        _xavier(self)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, time, nodes, channels = x.shape
        flattened = x.permute(2, 0, 1, 3).reshape(nodes, -1)
        propagated = []
        for name in self.support_names:
            value = torch.sparse.mm(getattr(self, name), flattened)
            propagated.append(value.reshape(nodes, batch, time, channels).permute(1, 2, 0, 3))
        features = torch.stack(propagated, dim=-1).reshape(batch, time, nodes, -1)
        return self.linear(features)


class SpatialConv(nn.Module):
    def __init__(self, supports: Sequence[torch.Tensor], c_in: int, c_out: int) -> None:
        super().__init__()
        self.c_in, self.c_out = c_in, c_out
        self.graph_conv = ChebyshevGraphConv(supports, c_in, c_out)
        self.residual_projection = nn.Linear(c_in, c_out, bias=False) if c_in > c_out else None
        _xavier(self)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.residual_projection is not None:
            residual = self.residual_projection(x)
        elif self.c_in < self.c_out:
            residual = F.pad(x, (0, self.c_out - self.c_in))
        else:
            residual = x
        return torch.relu(self.graph_conv(x) + residual)


class STConvBlock(nn.Module):
    def __init__(self, supports, n_nodes, kt, channels, dropout) -> None:
        super().__init__()
        c_in, c_hidden, c_out = channels
        self.temporal_in = TemporalConv(kt, c_in, c_hidden, "GLU")
        self.spatial = SpatialConv(supports, c_hidden, c_hidden)
        self.temporal_out = TemporalConv(kt, c_hidden, c_out, "relu")
        self.norm = NodeLayerNorm(n_nodes, c_out)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.norm(self.temporal_out(self.spatial(self.temporal_in(x)))))


class StaticFeatureEncoder(nn.Module):
    def __init__(self, input_channels: int, hidden_channels: int, dropout: float) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_channels, hidden_channels), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden_channels, hidden_channels), nn.ReLU(),
        )
        _xavier(self)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class SDSTGraphNet(nn.Module):
    """Static-Dynamic STGCN with intermediate 1x1-convolution fusion."""

    def __init__(self, supports, n_nodes: int, n_his: int = 12, n_pred: int = 9,
                 dynamic_channels: int = 6, static_channels: int = 14,
                 hidden_channels: int = 128,
                 blocks=((6, 32, 64), (64, 32, 128)), dropout: float = 0.0) -> None:
        super().__init__()
        if blocks[0][0] != dynamic_channels:
            raise ValueError("blocks[0][0] must equal dynamic_channels")
        self.block1 = STConvBlock(supports, n_nodes, 3, blocks[0], dropout)
        fusion_channels = blocks[0][-1]
        self.static_encoder = StaticFeatureEncoder(static_channels, fusion_channels, dropout)
        self.fusion_1x1 = nn.Conv2d(2 * fusion_channels, fusion_channels, 1)
        self.block2 = STConvBlock(supports, n_nodes, 3, blocks[1], dropout)
        self.readout = TemporalConv(n_his - 8, blocks[-1][-1], hidden_channels, "GLU")
        self.norm = NodeLayerNorm(n_nodes, hidden_channels)
        self.head = nn.Sequential(nn.Linear(hidden_channels, hidden_channels), nn.ReLU(),
                                  nn.Dropout(dropout), nn.Linear(hidden_channels, n_pred))
        _xavier(self.fusion_1x1)
        _xavier(self.head)
        self.n_nodes, self.n_his, self.static_channels = n_nodes, n_his, static_channels

    def forward(self, dynamic: torch.Tensor, static: torch.Tensor) -> torch.Tensor:
        if dynamic.ndim != 4 or tuple(dynamic.shape[1:3]) != (self.n_his, self.n_nodes):
            raise ValueError(f"Expected dynamic [B,{self.n_his},{self.n_nodes},C], got {tuple(dynamic.shape)}")
        if static.ndim != 2 or tuple(static.shape) != (self.n_nodes, self.static_channels):
            raise ValueError(f"Expected static [{self.n_nodes},{self.static_channels}], got {tuple(static.shape)}")
        dynamic = self.block1(dynamic)
        static_embedding = self.static_encoder(static)[None, None].expand(dynamic.shape[0], dynamic.shape[1], -1, -1)
        fused = torch.cat((dynamic, static_embedding), dim=-1)
        fused = self.fusion_1x1(fused.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        representation = self.norm(self.readout(self.block2(fused)))[:, 0]
        return self.head(representation).permute(0, 2, 1).unsqueeze(-1)

