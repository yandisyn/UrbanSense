import torch

from sdst_graphnet.model import SDSTGraphNet


def test_forward_shape():
    nodes = 7
    indices = torch.arange(nodes).repeat(2, 1)
    identity = torch.sparse_coo_tensor(indices, torch.ones(nodes), (nodes, nodes)).coalesce()
    model = SDSTGraphNet([identity] * 3, nodes, dynamic_channels=6, static_channels=14)
    output = model(torch.randn(2, 12, nodes, 6), torch.randn(nodes, 14))
    assert output.shape == (2, 9, nodes, 1)

