from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch.optim import RMSprop
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader

from sdst_graphnet.data import WindowDataset
from sdst_graphnet.graph import load_supports
from sdst_graphnet.metrics import masked_mse, masked_metrics
from sdst_graphnet.model import SDSTGraphNet


def evaluate(model, loader, static, device):
    model.eval()
    predictions, targets, masks = [], [], []
    with torch.no_grad():
        for dynamic, target, mask in loader:
            predictions.append(model(dynamic.to(device), static).cpu())
            targets.append(target)
            masks.append(mask)
    return masked_metrics(torch.cat(predictions), torch.cat(targets), torch.cat(masks))


def main() -> None:
    parser = argparse.ArgumentParser(description="Train SDST-GraphNet.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    seed = int(cfg.get("seed", 42))
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    device = torch.device(cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu"))
    data = cfg["data"]
    splits = np.load(data["splits"])
    static = torch.from_numpy(np.load(data["static"]).astype(np.float32)).to(device)
    supports = load_supports(data["adjacency"], cfg["model"].get("chebyshev_order", 3), device)
    datasets = {name: WindowDataset(data["dynamic"], data["target"], data["target_mask"], splits[name],
                                    cfg["model"]["history"], cfg["model"]["horizon"])
                for name in ("train", "val", "test")}
    loaders = {name: DataLoader(ds, batch_size=cfg["training"]["batch_size"],
                                shuffle=name == "train", num_workers=0) for name, ds in datasets.items()}
    model_cfg = cfg["model"]
    model = SDSTGraphNet(supports, n_nodes=static.shape[0], n_his=model_cfg["history"],
                         n_pred=model_cfg["horizon"], dynamic_channels=model_cfg["dynamic_channels"],
                         static_channels=static.shape[1], hidden_channels=model_cfg.get("hidden_channels", 128),
                         blocks=tuple(tuple(x) for x in model_cfg["blocks"]), dropout=model_cfg.get("dropout", 0.0)).to(device)
    optimizer = RMSprop(model.parameters(), lr=cfg["training"]["learning_rate"], alpha=.9, eps=1e-10)
    scheduler = StepLR(optimizer, step_size=5, gamma=.7)
    output = Path(cfg["output_dir"]); output.mkdir(parents=True, exist_ok=True)
    best, stale, history = float("inf"), 0, []
    for epoch in range(1, cfg["training"]["epochs"] + 1):
        model.train(); losses = []
        for dynamic, target, mask in loaders["train"]:
            optimizer.zero_grad(set_to_none=True)
            loss = masked_mse(model(dynamic.to(device), static), target.to(device), mask.to(device))
            loss.backward(); optimizer.step(); losses.append(loss.item())
        val = evaluate(model, loaders["val"], static, device)
        row = {"epoch": epoch, "train_masked_mse": float(np.mean(losses)), **{f"val_{k}": v for k, v in val.items()}}
        history.append(row); print(row)
        if val["mae"] < best:
            best, stale = val["mae"], 0
            torch.save({"format_version": 1, "model_name": "SDSTGraphNet", "architecture": model_cfg,
                        "n_nodes": int(static.shape[0]), "static_channels": int(static.shape[1]),
                        "state_dict": model.state_dict()}, output / "best_model.pt")
        else:
            stale += 1
        scheduler.step()
        patience = cfg["training"].get("patience")
        if patience is not None and stale >= patience:
            break
    (output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    checkpoint = torch.load(output / "best_model.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["state_dict"])
    metrics = {name: evaluate(model, loaders[name], static, device) for name in ("train", "val", "test")}
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

