# Weights

`sdst_graphnet_pretrained.pt` contains learned parameters and public architecture
metadata only. It intentionally excludes adjacency/Chebyshev matrices, node IDs,
road geometry, observations, dates, source paths, split definitions, and scaling
statistics. Use Git LFS if the repository host rejects the binary size.

